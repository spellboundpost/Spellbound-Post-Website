/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Klaviyo tracking utility.
 * In a real application, this would load the Klaviyo object from the window
 * and push events to it.
 */

export const trackEvent = (event: string, properties?: Record<string, any>) => {
  const publicKey = (import.meta as any).env?.VITE_KLAVIYO_PUBLIC_KEY;
  
  if (!publicKey || publicKey === 'YOUR_KLAVIYO_PUBLIC_KEY') {
    console.log('[Klaviyo Simulation]: Event tracked:', event, properties);
    return;
  }

  // Real Klaviyo integration logic would go here
  interface KlaviyoObject {
    push: (args: any[]) => void;
  }

  const _learnq = (window as any)._learnq || [];
  _learnq.push(['track', event, properties]);
  console.log('[Klaviyo]: Event tracked:', event, properties);
};

export const identifyUser = (email: string, properties?: Record<string, any>) => {
  const publicKey = (import.meta as any).env?.VITE_KLAVIYO_PUBLIC_KEY;
  
  if (!publicKey || publicKey === 'YOUR_KLAVIYO_PUBLIC_KEY') {
    console.log('[Klaviyo Simulation]: User identified:', email, properties);
    return;
  }

  const _learnq = (window as any)._learnq || [];
  _learnq.push(['identify', {
    '$email': email,
    ...properties
  }]);
  console.log('[Klaviyo]: User identified:', email);
};
