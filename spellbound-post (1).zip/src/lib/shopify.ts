import Client from 'shopify-buy';

/**
 * To use your real Shopify data:
 * 1. Go to your Shopify Admin > Settings > Apps and sales channels > Develop apps.
 * 2. Create a custom app and enable the 'Storefront API' with necessary permissions.
 * 3. Copy the 'Storefront access token' and your store domain (e.g., your-store.myshopify.com).
 * 4. Add them to your .env file as VITE_SHOPIFY_STORE_DOMAIN and VITE_SHOPIFY_STOREFRONT_ACCESS_TOKEN.
 */

const domain = import.meta.env.VITE_SHOPIFY_STORE_DOMAIN || '';
const storefrontAccessToken = import.meta.env.VITE_SHOPIFY_STOREFRONT_ACCESS_TOKEN || '';

let client: Client | null = null;

if (domain && storefrontAccessToken) {
  client = Client.buildClient({
    domain,
    storefrontAccessToken,
  });
}

export const getShopifyClient = () => client;

export const fetchShopifyProducts = async () => {
  if (!client) return null;
  try {
    return await client.product.fetchAll();
  } catch (error) {
    console.error('Error fetching Shopify products:', error);
    return null;
  }
};

export const createCheckout = async () => {
  if (!client) return null;
  try {
    return await client.checkout.create();
  } catch (error) {
    console.error('Error creating Shopify checkout:', error);
    return null;
  }
};
