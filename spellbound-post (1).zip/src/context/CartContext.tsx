/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { trackEvent } from '../lib/klaviyo';
import { getShopifyClient } from '../lib/shopify';

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  category: 'story' | 'merch';
}

export interface CartItem extends Product {
  quantity: number;
}

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  checkout: () => Promise<void>;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('spellbound_cart');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('spellbound_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        trackEvent('Added to Cart', { product_id: product.id, name: product.name, quantity: existing.quantity + 1 });
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      trackEvent('Added to Cart', { product_id: product.id, name: product.name, quantity: 1 });
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => {
      const item = prev.find(i => i.id === productId);
      if (item) {
        trackEvent('Removed from Cart', { product_id: productId, name: item.name });
      }
      return prev.filter(item => item.id !== productId);
    });
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => 
      item.id === productId ? { ...item, quantity } : item
    ));
  };

  const clearCart = () => setCart([]);

  const checkout = async () => {
    const shopify = getShopifyClient();
    if (shopify) {
      try {
        const checkout = await shopify.checkout.create();
        const lineItems = cart.map(item => ({
          variantId: item.id, // Assume the IDs are Shopify variant IDs
          quantity: item.quantity,
        }));
        await shopify.checkout.addLineItems(checkout.id, lineItems);
        window.location.href = checkout.webUrl;
      } catch (error) {
        console.error('Shopify Checkout Error:', error);
      }
    } else {
      // Fallback for demo or non-Shopify mode
      window.location.href = '/checkout';
    }
  };

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
  const totalPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  return (
    <CartContext.Provider value={{ 
      cart, 
      addToCart, 
      removeFromCart, 
      updateQuantity, 
      clearCart,
      checkout,
      totalItems,
      totalPrice
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
