/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Link } from 'react-router-dom';
import { Mail, Instagram, Twitter, Feather } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-ink text-parchment py-16 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 lg:gap-24">
          <div className="col-span-1 md:col-span-2">
            <div className="mb-6">
              <Link to="/" className="inline-block h-20">
                <img 
                  src="/logo.png" 
                  alt="Spellbound Post" 
                  className="h-full w-auto object-contain brightness-0 invert" 
                />
              </Link>
            </div>
            <p className="text-parchment/60 max-w-md leading-relaxed mb-8">
              Reviving the art of letter-writing through historical fantasy and handcrafted romance. Each dispatch is a gateway to another time.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-gold transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-gold transition-colors"><Twitter size={20} /></a>
              <a href="#" className="hover:text-gold transition-colors"><Mail size={20} /></a>
            </div>
          </div>
          
          <div>
            <h4 className="font-display text-2xl mb-6 text-gold">Quick Links</h4>
            <ul className="space-y-4 text-parchment/70 text-sm italic font-serif">
              <li><Link to="/stories" className="hover:text-gold transition-colors underline-offset-4 hover:underline">Choose Your Story</Link></li>
              <li><Link to="/how-it-works" className="hover:text-gold transition-colors underline-offset-4 hover:underline">How It Works</Link></li>
              <li><Link to="/merch" className="hover:text-gold transition-colors underline-offset-4 hover:underline">Merch Shop</Link></li>
              <li><Link to="/faqs" className="hover:text-gold transition-colors underline-offset-4 hover:underline">Support & FAQs</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display text-2xl mb-6 text-gold">Join the Dispatch</h4>
            <p className="text-parchment/70 text-sm mb-4 italic font-serif">Receive cryptic riddles and shop updates.</p>
            <form className="flex">
              <input 
                type="email" 
                placeholder="Your email address"
                className="bg-parchment/10 border border-parchment/20 px-4 py-2 text-sm focus:outline-none focus:border-gold w-full"
              />
              <button className="bg-parchment text-ink px-4 py-2 text-xs font-bold uppercase tracking-widest hover:bg-gold transition-colors">
                Sign
              </button>
            </form>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-parchment/10 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-[0.2em] text-parchment/40">
          <p>© 2026 Spellbound Post. All Rights Reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-parchment">Privacy Policy</a>
            <a href="#" className="hover:text-parchment">Terms of Service</a>
            <a href="#" className="hover:text-parchment">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
