/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Mail, Feather } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { totalItems } = useCart();
  const location = useLocation();

  const links = [
    { name: 'How It Works', path: '/how-it-works' },
    { name: 'Choose Your Story', path: '/stories' },
    { name: 'Merch', path: '/merch' },
    { name: 'About Us', path: '/about' },
    { name: 'FAQs', path: '/faqs' },
  ];

  const activeLink = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-parchment/90 backdrop-blur-sm border-b border-ink/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-20">
          <div className="flex-shrink-0">
            <Link to="/" className="group flex items-center gap-3">
              <div className="wax-seal w-12 h-12 group-hover:scale-110 transition-transform">
                <Mail size={22} className="text-white" />
              </div>
              <span className="font-display text-xl font-bold tracking-widest text-ink hidden lg:block">
                Spellbound Post
              </span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center ml-6 lg:ml-10 space-x-6 lg:space-x-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-all hover:text-seal tracking-tight ${
                  activeLink(link.path) ? 'text-seal border-b-2 border-seal pb-1' : 'text-ink/70'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="flex ml-auto items-center gap-4">
            <Link to="/cart" className="relative p-2 group hidden md:block">
              <ShoppingBag size={24} className="text-ink group-hover:text-seal transition-colors" />
              {totalItems > 0 && (
                <span className="absolute top-0 right-0 bg-seal text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            
            <div className="md:hidden flex items-center gap-4">
              <Link to="/cart" className="relative p-2">
                <ShoppingBag size={24} className="text-ink" />
                {totalItems > 0 && (
                  <span className="absolute top-0 right-0 bg-seal text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Link>
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 text-ink focus:outline-none"
              >
                {isOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-parchment-dark overflow-hidden border-b border-ink/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-4">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className="block text-lg font-serif text-ink hover:text-seal"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
