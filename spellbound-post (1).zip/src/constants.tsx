/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product } from './context/CartContext';

/**
 * SHOPIFY INTEGRATION:
 * To sync with your real Shopify store:
 * 1. Set environment variables in .env as per .env.example
 * 2. Replace 'id' fields below with your Shopify Product Variant GIDs
 *    (e.g., 'gid://shopify/ProductVariant/12345678912345')
 */
export const STORIES: Product[] = [
  {
    id: 'dear-professor',
    name: 'Dear Professor',
    price: 35.00,
    category: 'story',
    image: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?q=80&w=800&auto=format&fit=crop',
    description: 'When Margaret inherits her estranged uncle’s countryside estate, she also inherits his collection of peculiar magical creatures: a dangerous kelpie in the river, a balding phoenix, and a highly ill-tempered cat. Overwhelmed, Margaret seeks the help of Professor Ebenezer, an expert in magical ecology. As the professor steps in, Margaret soon realizes that these creatures are only the beginning of her journey.'
  }
];

export const MERCH: Product[] = [
  {
    id: 'merch-1',
    name: 'Dragon Inkwell',
    price: 25.00,
    category: 'merch',
    image: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?q=80&w=800&auto=format&fit=crop',
    description: 'Hand-carved inkwell shaped like a sleeping guardian.'
  },
  {
    id: 'merch-2',
    name: 'Spellbound Stationery Set',
    price: 18.00,
    category: 'merch',
    image: 'https://images.unsplash.com/photo-1586075010633-247092154749?q=80&w=800&auto=format&fit=crop',
    description: 'Premium parchment paper and envelopes with a crimson wax seal.'
  },
  {
    id: 'merch-3',
    name: 'The Cartographer\'s Satchel',
    price: 85.00,
    category: 'merch',
    image: 'https://images.unsplash.com/photo-1547949003-9792a18a2601?q=80&w=800&auto=format&fit=crop',
    description: 'Genuine leather bag for the traveling storyteller.'
  }
];

export const FAQS = [
  {
    question: "How long does delivery take?",
    answer: "Our owls (and postal workers) usually take 3-5 business days to deliver a story installment within the kingdom."
  },
  {
    question: "Can I cancel my story subscription?",
    answer: "You can pause or end your chronicle at any time via your account portal, though once a letter is sealed, it must find its way to you."
  },
  {
    question: "Are the letters handmade?",
    answer: "Each piece of correspondence is printed on high-quality parchment, hand-folded, and sealed with real wax."
  },
  {
    question: "Do you ship internationally?",
    answer: "Yes, we ship to most realms across the seas, though trans-dimensional shipping is still in beta."
  }
];
