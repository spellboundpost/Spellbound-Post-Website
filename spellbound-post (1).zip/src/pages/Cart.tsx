/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, totalPrice, checkout } = useCart();

  if (cart.length === 0) {
    return (
      <div className="pt-40 pb-20 max-w-7xl mx-auto px-4 text-center">
        <div className="wax-seal w-20 h-20 mx-auto mb-8 opacity-20">
          <ShoppingBag size={40} />
        </div>
        <h1 className="text-4xl font-serif text-ink mb-6">Your satchel is empty</h1>
        <p className="text-ink/60 mb-10 italic">Your journey hasn't started yet. Browse our chronicles to begin.</p>
        <Link to="/stories" className="bg-seal text-white px-8 py-4 text-sm font-bold uppercase tracking-widest hover:bg-ink transition-all">
          Explore Stories
        </Link>
      </div>
    );
  }

  return (
    <main className="pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-5xl font-serif text-ink mb-12">Your Dispatch</h1>
        
        <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 space-y-8">
            {cart.map((item) => (
              <motion.div 
                key={item.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-6 pb-8 border-b border-ink/10"
              >
                <div className="w-24 h-24 sm:w-32 sm:h-32 flex-shrink-0 bg-parchment-dark rounded overflow-hidden shadow-sm">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-serif text-ink mb-1">{item.name}</h3>
                  <p className="text-sm text-ink/40 uppercase tracking-widest mb-4">{item.category}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center border border-ink/10">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-parchment-dark transition-colors"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="px-4 font-mono text-sm">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-parchment-dark transition-colors"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-ink/40 hover:text-seal transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                <div className="text-right font-serif text-lg">
                  ${(item.price * item.quantity).toFixed(2)}
                </div>
              </motion.div>
            ))}
            
            <Link to="/stories" className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-ink hover:text-seal transition-colors pt-4">
              <ArrowLeft size={16} /> Continue Shopping
            </Link>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white parchment-shadow p-8 sticky top-32">
              <h3 className="text-2xl font-serif mb-6 border-b border-ink/10 pb-4">Order Summary</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-ink/60">
                  <span>Subtotal</span>
                  <span>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-ink/60">
                  <span>Owl Delivery</span>
                  <span className="italic">Calculated at checkout</span>
                </div>
                <div className="historical-line my-4" />
                <div className="flex justify-between text-xl font-serif text-ink">
                  <span>Total</span>
                  <span>${totalPrice.toFixed(2)}</span>
                </div>
              </div>
              <button 
                onClick={checkout}
                className="block w-full bg-seal text-white text-center py-5 text-sm font-bold uppercase tracking-widest hover:bg-ink transition-all shadow-xl"
              >
                Proceed to Checkout
              </button>
              <p className="mt-6 text-center text-[10px] text-ink/40 uppercase tracking-widest">
                Secure 256-bit Encrypted Checkout
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
