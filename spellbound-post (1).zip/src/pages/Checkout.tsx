/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { Lock, ShieldCheck, CreditCard, Truck, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { trackEvent, identifyUser } from '../lib/klaviyo';

export default function Checkout() {
  const { cart, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    zip: '',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const nextStep = () => {
    if (step === 1 && formData.email) {
      identifyUser(formData.email, { first_name: formData.firstName, last_name: formData.lastName });
      trackEvent('Started Checkout');
    }
    setStep(step + 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    trackEvent('Placed Order', { 
      value: totalPrice, 
      items: cart.map(i => i.name),
      email: formData.email 
    });
    setStep(4);
    clearCart();
  };

  if (step === 4) {
    return (
      <div className="pt-40 pb-20 max-w-lg mx-auto px-4 text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <div className="wax-seal w-24 h-24 mx-auto mb-10 bg-green-800">
            <CheckCircle2 size={48} />
          </div>
          <h1 className="text-4xl font-serif text-ink mb-6">Your Order has been Sealed</h1>
          <p className="text-ink/60 mb-10 italic leading-relaxed text-lg">
            A confirmation raven is flying to your inbox. Our scribes are already preparing your first dispatch.
          </p>
          <a href="/" className="inline-block bg-ink text-white px-10 py-5 text-sm font-bold uppercase tracking-widest hover:bg-gold hover:text-ink transition-all shadow-xl">
            Return to the Library
          </a>
        </motion.div>
      </div>
    );
  }

  return (
    <main className="pt-20 bg-parchment-dark/5 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-2 gap-20">
        <div>
          <div className="flex items-center gap-4 mb-12">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  step >= s ? 'bg-seal text-white' : 'bg-ink/10 text-ink/40'
                }`}>
                  {s}
                </div>
                {s < 3 && <div className={`w-12 h-px ${step > s ? 'bg-seal' : 'bg-ink/10'}`} />}
              </div>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
            >
              {step === 1 && (
                <div className="space-y-8">
                  <h2 className="text-3xl font-serif text-ink">Identity & Dispatch</h2>
                  <div className="grid gap-6">
                    <input 
                      type="email" name="email" placeholder="Email Address" 
                      className="checkout-input" value={formData.email} onChange={handleInputChange} 
                    />
                    <div className="grid grid-cols-2 gap-6">
                      <input 
                        type="text" name="firstName" placeholder="First Name" 
                        className="checkout-input" value={formData.firstName} onChange={handleInputChange} 
                      />
                      <input 
                        type="text" name="lastName" placeholder="Last Name" 
                        className="checkout-input" value={formData.lastName} onChange={handleInputChange} 
                      />
                    </div>
                  </div>
                  <button onClick={nextStep} disabled={!formData.email} className="checkout-btn">
                    Continue to Delivery
                  </button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-8">
                  <h2 className="text-3xl font-serif text-ink flex items-center gap-3">
                    <Truck size={24} /> Delivery Location
                  </h2>
                  <div className="grid gap-6">
                    <input 
                      type="text" name="address" placeholder="Physical Address" 
                      className="checkout-input" value={formData.address} onChange={handleInputChange} 
                    />
                    <div className="grid grid-cols-2 gap-6">
                      <input 
                        type="text" name="city" placeholder="City / Settlement" 
                        className="checkout-input" value={formData.city} onChange={handleInputChange} 
                      />
                      <input 
                        type="text" name="zip" placeholder="Postal Code" 
                        className="checkout-input" value={formData.zip} onChange={handleInputChange} 
                      />
                    </div>
                  </div>
                  <div className="flex gap-4 pt-4">
                    <button onClick={() => setStep(1)} className="checkout-btn-secondary">Back</button>
                    <button onClick={nextStep} className="checkout-btn">Continue to Payment</button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <form onSubmit={handleSubmit} className="space-y-8">
                  <h2 className="text-3xl font-serif text-ink flex items-center gap-3">
                    <CreditCard size={24} /> Tribute & Seal
                  </h2>
                  <div className="bg-white p-8 rounded-lg shadow-inner border border-ink/5 space-y-6">
                    <div className="flex justify-between items-center mb-2">
                       <span className="text-xs font-bold uppercase tracking-widest text-ink/40">Secure Payment</span>
                       <div className="flex gap-2">
                          <div className="w-8 h-5 bg-gray-200 rounded" />
                          <div className="w-8 h-5 bg-gray-200 rounded" />
                       </div>
                    </div>
                    <input 
                      type="text" name="cardNumber" placeholder="Card Number" 
                      className="checkout-input" value={formData.cardNumber} onChange={handleInputChange} 
                    />
                    <div className="grid grid-cols-2 gap-6">
                      <input 
                        type="text" name="expiry" placeholder="MM/YY" 
                        className="checkout-input" value={formData.expiry} onChange={handleInputChange} 
                      />
                      <input 
                        type="text" name="cvc" placeholder="CVC" 
                        className="checkout-input" value={formData.cvc} onChange={handleInputChange} 
                      />
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button type="button" onClick={() => setStep(2)} className="checkout-btn-secondary">Back</button>
                    <button type="submit" className="checkout-btn bg-green-900">Place Order — ${totalPrice.toFixed(2)}</button>
                  </div>
                  <div className="flex items-center gap-2 justify-center text-[10px] text-ink/40 uppercase tracking-widest">
                    <ShieldCheck size={12} /> Powered by Stripe Secure Protocols
                  </div>
                </form>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="lg:border-l border-ink/10 lg:pl-20">
          <h3 className="text-xl font-serif mb-8 flex items-center gap-2">
            Order Review <span className="text-xs font-sans text-ink/40">({cart.length} items)</span>
          </h3>
          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-4 mb-8">
            {cart.map((item) => (
              <div key={item.id} className="flex gap-4">
                <div className="w-16 h-16 bg-parchment-dark rounded overflow-hidden">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-ink">{item.name}</h4>
                  <p className="text-xs text-ink/40 italic">Qty: {item.quantity}</p>
                </div>
                <div className="text-sm font-serif">${(item.price * item.quantity).toFixed(2)}</div>
              </div>
            ))}
          </div>
          <div className="space-y-3 pt-8 border-t border-ink/10">
            <div className="flex justify-between text-sm text-ink/60">
              <span>Subtotal</span>
              <span>${totalPrice.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-ink/60">
              <span>Owl Dispatch</span>
              <span>$5.00</span>
            </div>
            <div className="flex justify-between text-lg font-serif text-ink pt-2">
              <span>Grand Total</span>
              <span>${(totalPrice + 5).toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
      
      <style>{`
        .checkout-input {
          @apply w-full bg-white border border-ink/10 px-4 py-4 focus:outline-none focus:border-seal transition-colors font-serif;
        }
        .checkout-btn {
          @apply w-full bg-seal text-white py-5 px-8 text-sm font-bold uppercase tracking-widest hover:bg-ink transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl;
        }
        .checkout-btn-secondary {
          @apply w-24 border border-ink/20 py-5 px-4 text-xs font-bold uppercase tracking-widest hover:bg-ink hover:text-white transition-all;
        }
      `}</style>
    </main>
  );
}
