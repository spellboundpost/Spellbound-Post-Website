/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { MERCH } from '../constants';
import { useCart } from '../context/CartContext';
import { ShoppingBag, Eye } from 'lucide-react';

export default function Merch() {
  const { addToCart } = useCart();

  return (
    <main className="pt-20">
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <span className="text-secondary-label text-xs font-bold uppercase tracking-[0.3em] text-seal mb-4 block">The Scribe's Study</span>
        <h1 className="text-6xl md:text-8xl font-display text-ink mb-6">Curiosities & Tools</h1>
        <p className="text-2xl text-ink/60 max-w-2xl mx-auto font-serif italic leading-relaxed">
          Enhance your correspondence experience with handcrafted tools and artifacts from around the world.
        </p>
      </header>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16">
          {MERCH.map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="flex flex-col group"
            >
              <div className="relative aspect-square mb-8 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                />
                <div className="absolute inset-0 bg-ink/30 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                  <div className="flex gap-2">
                    <button 
                      onClick={() => addToCart(item)}
                      className="flex-1 bg-parchment text-ink py-4 text-xs font-bold uppercase tracking-widest hover:bg-gold transition-colors flex items-center justify-center gap-2"
                    >
                      <ShoppingBag size={14} /> Add to Cart
                    </button>
                    <button className="bg-ink text-white p-4 hover:bg-seal transition-colors">
                      <Eye size={16} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-display text-ink mb-2">{item.name}</h3>
                <p className="text-ink/60 text-sm italic mb-4 leading-relaxed px-4 font-serif">
                  {item.description}
                </p>
                <p className="text-xl text-seal font-display">${item.price.toFixed(2)}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Craftsmanship focus */}
      <section className="bg-parchment-dark/20 py-24 border-y border-ink/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 items-center gap-16">
          <div className="order-2 md:order-1">
             <span className="text-xs font-bold uppercase tracking-[0.3em] text-seal mb-4 block underline underline-offset-8">Heritage Quality</span>
             <h2 className="text-5xl font-display text-ink mb-8 leading-tight">Tools that Tell Their Own Stories</h2>
             <p className="text-ink/70 italic text-xl leading-relaxed mb-8 font-serif">
               Our curiosities are not just decorative; they are artifacts of a world that values the weight of paper and the ritual of the seal. Each item is sourced from traditional artisans who keep historical crafts alive.
             </p>
             <button className="text-sm font-bold uppercase tracking-widest text-ink border-b-2 border-gold pb-1 hover:text-seal hover:border-seal transition-all">
               Our Artisan Network
             </button>
          </div>
          <div className="order-1 md:order-2">
            <div className="aspect-[4/5] bg-ink/5 relative overflow-hidden shadow-2xl skew-y-3">
               <img 
                 src="https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?q=80&w=800&auto=format&fit=crop" 
                 alt="Artisan Craftsmanship" 
                 className="w-full h-full object-cover grayscale brightness-90"
               />
               <div className="absolute inset-0 bg-seal/10 mix-blend-multiply" />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
