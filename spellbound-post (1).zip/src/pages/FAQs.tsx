/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { FAQS } from '../constants';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { useState } from 'react';

export default function FAQs() {
  return (
    <main className="pt-20">
      <header className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="wax-seal w-16 h-16 mx-auto mb-8">
           <HelpCircle size={32} />
        </div>
        <h1 className="text-6xl md:text-8xl font-display text-ink mb-6">Inquiries & Answers</h1>
        <p className="text-2xl text-ink/60 font-serif italic leading-relaxed">
          Seeking clarity? Here are the most common questions from our fellow adventurers.
        </p>
      </header>

      <section className="max-w-3xl mx-auto px-4 pb-32">
        <div className="space-y-4">
          {FAQS.map((faq, index) => (
            <FAQItem key={index} faq={faq} index={index} />
          ))}
        </div>
        
        <div className="mt-20 p-12 bg-parchment-dark/30 text-center border-2 border-dashed border-ink/10">
           <h3 className="text-2xl font-serif text-ink mb-4">Seeking further guidance?</h3>
           <p className="text-ink/60 italic mb-8">If your question remains unanswered, send us a thoughtful message.</p>
           <a href="mailto:scribes@spellboundpost.com" className="text-sm font-bold uppercase tracking-widest text-seal border-b border-seal pb-1 hover:text-ink hover:border-ink transition-all">
             Contact our Scribes
           </a>
        </div>
      </section>
    </main>
  );
}

function FAQItem({ faq, index }: any) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="border-b border-ink/10"
    >
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-8 flex items-center justify-between text-left focus:outline-none group"
      >
        <span className="text-xl md:text-2xl font-display text-ink group-hover:text-seal transition-colors">{faq.question}</span>
        <ChevronDown 
          size={20} 
          className={`text-ink/30 transition-transform duration-300 ${isOpen ? 'rotate-180 text-seal' : ''}`} 
        />
      </button>
      <motion.div
         initial={false}
         animate={{ height: isOpen ? 'auto' : 0, opacity: isOpen ? 1 : 0 }}
         className="overflow-hidden"
      >
        <p className="pb-8 text-ink/70 leading-relaxed italic text-lg pr-12">
          {faq.answer}
        </p>
      </motion.div>
    </motion.div>
  );
}
