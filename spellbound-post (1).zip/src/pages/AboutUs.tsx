/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Mail, Heart, History, Users } from 'lucide-react';

export default function AboutUs() {
  return (
    <main className="pt-20">
      <section className="max-w-4xl mx-auto px-4 py-24 text-center">
        <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
        >
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-seal mb-4 block underline">Our Chronicle</span>
          <h1 className="text-6xl md:text-7xl font-display text-ink mb-10 leading-tight">Reviving the Magic <br/> of the Post</h1>
          <p className="text-2xl text-ink/70 font-serif italic leading-relaxed mb-12">
            In an era of instant digital echoes, we believe there is profound power in the tactile, the patient, and the physical.
          </p>
          <div className="historical-line mb-12" />
        </motion.div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-white shadow-2xl relative z-10 -mb-20">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-serif text-ink mb-6">The Handcrafted Truth</h2>
            <p className="text-ink/70 leading-relaxed mb-6 text-lg">
              Spellbound Post began in a small cottage where history and imagination intertwined over teacups and inkpots. Our founder, a curator of old-world lore, wanted to create a way for readers to experience the magic of a physical letter and the warmth of a story well-told.
            </p>
            <p className="text-ink/70 leading-relaxed mb-8 text-lg">
              Every letter we send is more than just paper; it is a meticulously crafted portal. From the weight of the parchment to the scent of the countryside and the gentle swirl of the wax seal, we aim to capture the romance and wonder of another age.
            </p>
            <div className="grid grid-cols-2 gap-8">
               <div>
                  <h4 className="font-serif text-seal text-2xl mb-2">12,000+</h4>
                  <p className="text-xs uppercase tracking-widest text-ink/40">Letters Dispatched</p>
               </div>
               <div>
                  <h4 className="font-serif text-seal text-2xl mb-2">32</h4>
                  <p className="text-xs uppercase tracking-widest text-ink/40">Unique Worlds</p>
               </div>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square bg-parchment-dark overflow-hidden transform rotate-2 shadow-xl group">
               <img 
                 src="https://images.unsplash.com/photo-1518349619113-03114f06ac3a?q=80&w=800&auto=format&fit=crop" 
                 alt="The Workshop" 
                 className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
               />
               <div className="absolute inset-0 bg-ink/10" />
            </div>
            <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-seal text-white p-8 flex flex-col justify-center transform -rotate-12 shadow-2xl">
               <p className="font-serif text-3xl italic">Made with Ink & Heart</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-ink pt-40 pb-24 text-parchment">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="text-center mb-20">
              <h2 className="text-4xl font-serif mb-4">The Custodians</h2>
              <p className="text-parchment/60 italic">Meet the minds behind the mail.</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {[
                { name: "Alistair Thorne", role: "Master Scribe", bio: "Curator of historical myths and legendary tales of old." },
                { name: "Eliza Vane", role: "Artisan Illustratix", bio: "Capturing the magic and romance of every scene in pen and ink." },
                { name: "Julian Gray", role: "Logistics Wizard", bio: "Ensuring every letter finds its way across the threshold." }
              ].map((member, i) => (
                <div key={i} className="text-center group">
                  <div className="w-32 h-32 mx-auto bg-parchment/10 rounded-full mb-6 relative overflow-hidden border border-gold/20">
                    <div className="absolute inset-x-0 bottom-0 h-0 bg-gold/50 group-hover:h-full transition-all duration-500" />
                    <Users className="absolute inset-0 m-auto text-gold" size={40} />
                  </div>
                  <h3 className="text-2xl font-serif mb-2 text-gold">{member.name}</h3>
                  <p className="text-xs uppercase tracking-[0.2em] mb-4 text-parchment/40">{member.role}</p>
                  <p className="text-parchment/60 text-sm italic italic">{member.bio}</p>
                </div>
              ))}
           </div>
        </div>
      </section>
    </main>
  );
}
