/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { ArrowRight, BookOpen, Mail, Zap, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { STORIES } from '../constants';
import { useCart } from '../context/CartContext';

export default function Home() {
  const { addToCart } = useCart();

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-12 pb-32 flex flex-col items-center text-center px-4 min-h-[90vh] justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="max-w-5xl"
        >
          <div className="mb-4 inline-block">
            <div className="mx-auto w-80 h-80 sm:w-[550px] sm:h-[550px] relative">
              <div className="absolute inset-0 bg-seal/5 rounded-full blur-3xl scale-110" />
              <img 
                src="/logo.png" 
                alt="Spellbound Post Logo" 
                className="relative z-10 w-full h-full object-contain mix-blend-multiply"
              />
            </div>
          </div>
          
          <h1 className="sr-only">Spellbound Post</h1>
          
          <p className="text-2xl sm:text-3xl text-ink/80 max-w-3xl mx-auto mb-16 leading-relaxed font-serif italic py-4">
            Immersive correspondence and handcrafted tales <br className="hidden sm:block" /> 
            delivered directly to your doorstep.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link to="/stories" className="bg-seal text-white px-10 py-5 text-sm font-bold uppercase tracking-[0.2em] hover:bg-ink transition-all shadow-2xl hover:scale-105 inline-flex items-center gap-3">
              Begin Your Story <ArrowRight size={20} />
            </Link>
            <Link to="/how-it-works" className="bg-white/50 backdrop-blur-sm border-2 border-ink text-ink px-10 py-5 text-sm font-bold uppercase tracking-[0.2em] hover:bg-ink hover:text-white transition-all shadow-xl hover:scale-105">
              The Art of the Post
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Featured Stories */}
      <section className="py-24 bg-parchment-dark/30 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-seal mb-2 block">The Rural Dispatch</span>
              <h2 className="text-4xl font-display text-ink">Choose Your Story</h2>
            </div>
            <Link to="/stories" className="text-sm font-bold text-ink hover:text-seal group hidden sm:flex items-center gap-2 transition-colors">
              View All Stories <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className={`grid grid-cols-1 ${STORIES.length > 1 ? 'md:grid-cols-3' : 'md:grid-cols-1 max-w-lg mx-auto text-center'} gap-8`}>
            {STORIES.map((story, i) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-[3/4] mb-6 overflow-hidden parchment-shadow">
                  <img 
                    src={story.image} 
                    alt={story.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-ink/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                      onClick={(e) => { e.preventDefault(); addToCart(story); }}
                      className="bg-parchment text-ink px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-gold transition-colors"
                    >
                      Summon to Cart
                    </button>
                  </div>
                </div>
                <h3 className="text-2xl font-display text-ink mb-2 group-hover:text-seal transition-colors">{story.name}</h3>
                <p className="text-ink/60 text-sm mb-4 line-clamp-2 italic">{story.description}</p>
                <p className="font-serif text-lg text-seal">${story.price.toFixed(2)}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-parchment-dark flex items-center justify-center mb-6 text-seal">
                <BookOpen size={32} />
              </div>
              <h3 className="text-2xl font-display mb-4">Original Fiction</h3>
              <p className="text-ink/60 text-sm leading-relaxed">
                Handcrafted narratives penned by talented authors, exploring the intersection of history, magic, and the heart.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-parchment-dark flex items-center justify-center mb-6 text-seal">
                <Mail size={32} />
              </div>
              <h3 className="text-2xl font-display mb-4">Physical Artifacts</h3>
              <p className="text-ink/60 text-sm leading-relaxed">
                Letters, maps, and historical artifacts delivered through the post, designed to be held, felt, and cherished.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-parchment-dark flex items-center justify-center mb-6 text-seal">
                <Sparkles size={32} />
              </div>
              <h3 className="text-2xl font-display mb-4">Immersive Discovery</h3>
              <p className="text-ink/60 text-sm leading-relaxed">
                Magic and romance woven into every envelope. Watch your world expand with every letter you receive.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Quote */}
      <section className="py-32 bg-ink text-parchment text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          {/* Subtle decoration */}
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/lined-paper.png')]" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <span className="text-seal text-6xl font-serif opacity-30 mb-8 block">"</span>
            <p className="text-3xl md:text-5xl font-display italic mb-12 leading-tight">
              A story is a letter to the heart <br className="hidden md:block" /> written in the ink of stars.
            </p>
            <div className="w-12 h-px bg-gold mx-auto mb-12" />
            <Link to="/about" className="text-sm font-bold uppercase tracking-[0.3em] hover:text-gold transition-colors">
              Our Origin Story
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
