/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { STORIES } from '../constants';
import { useCart } from '../context/CartContext';
import { ShoppingCart, Plus } from 'lucide-react';

export default function ChooseYourStory() {
  const { addToCart } = useCart();

  return (
    <main className="pt-20 bg-parchment">
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <span className="text-xs font-bold uppercase tracking-[0.3em] text-seal mb-4 block">Archive Selection</span>
        <h1 className="text-6xl md:text-8xl font-display text-ink mb-6">Tales from the Rolling Heather</h1>
        <p className="text-2xl text-ink/60 max-w-2xl font-serif italic border-l-4 border-gold pl-8 leading-relaxed">
          Each chronicle is a self-contained experience consisting of multiple physical deliveries. Choose your path wisely.
        </p>
      </header>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-32">
        <div className={`grid grid-cols-1 ${STORIES.length > 1 ? 'md:grid-cols-2 lg:grid-cols-3' : 'max-w-xl mx-auto'} gap-12`}>
          {STORIES.map((story) => (
            <motion.div
              key={story.id}
              layoutId={story.id}
              className="bg-white parchment-shadow group overflow-hidden flex flex-col h-full hover:-translate-y-2 transition-transform duration-500"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img 
                  src={story.image} 
                  alt={story.name} 
                  className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 transition-all duration-700" 
                />
                <div className="absolute top-4 right-4 bg-parchment px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest text-ink/60 border border-ink/10">
                  Serialized Epic
                </div>
              </div>
              <div className="p-8 flex-1 flex flex-col">
                <h3 className="text-3xl font-display text-ink mb-4 group-hover:text-seal transition-colors">{story.name}</h3>
                <p className="text-ink/60 text-lg italic mb-8 flex-1 leading-relaxed font-serif">
                  {story.description}
                </p>
                <div className="historical-line mb-8" />
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-display text-ink">${story.price.toFixed(2)}</span>
                  <button 
                    onClick={() => addToCart(story)}
                    className="flex items-center gap-2 bg-ink text-white px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-gold transition-colors"
                  >
                    <Plus size={14} /> Add to Cart
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="bg-ink text-parchment py-24 mb-20 relative">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <BookBadge />
          <p className="text-2xl font-serif italic mb-8 leading-relaxed">
            "Receiving letters from Spellbound Post feels like having a secret friend in a world filled with magic. I look forward to my mailbox more than I ever have before."
          </p>
          <p className="text-xs font-bold uppercase tracking-widest text-gold">— Lady Elara, Subscriber</p>
        </div>
      </section>
    </main>
  );
}

function BookBadge() {
  return (
    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-gold mb-8 text-gold">
      <ShoppingCart size={20} />
    </div>
  );
}
