/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Mail, Book, Compass, Send } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: <Book size={32} />,
      title: "Select Your Story",
      description: "Choose your path from our collection of historical fantasies and romances. Every story is a gateway to another time and place."
    },
    {
      icon: <Mail size={32} />,
      title: "Dispatch Begins",
      description: "Our artisans meticulously hand-pack every delivery. Your personalized letters and artifacts will arrive directly on your doorstep, ready to be unsealed."
    },
    {
      icon: <Compass size={32} />,
      title: "Step Into the Story",
      description: "Open your mail and let the narrative unfold. Experience a world where historical charm meets the magic of fantasy, one letter at a time."
    }
  ];

  return (
    <main className="pt-20">
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
        >
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-seal mb-4 block underline underline-offset-8">The Process</span>
          <h1 className="text-6xl md:text-8xl font-display mb-8 text-ink">The Path of the Post</h1>
          <p className="text-xl md:text-2xl text-ink/60 max-w-2xl mx-auto italic font-serif leading-relaxed px-4">
            Wondering how a letter becomes a legend? <br className="hidden sm:block" /> Here is how we bridge the gap between imagination and reality.
          </p>
        </motion.div>
      </section>

      <section className="bg-parchment-dark/10 py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-24">
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className={`flex flex-col md:flex-row items-center gap-12 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}
              >
                <div className="flex-shrink-0 w-24 h-24 wax-seal text-white transform hover:rotate-12 transition-transform">
                  {step.icon}
                </div>
                <div className={`flex-1 text-center ${index % 2 === 0 ? 'md:text-left' : 'md:text-right'}`}>
                  <span className="font-display text-gold text-5xl opacity-40 mb-2 block">0{index + 1}</span>
                  <h2 className="text-4xl font-display text-ink mb-4">{step.title}</h2>
                  <p className="text-ink/70 leading-relaxed text-lg italic font-serif">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 text-center bg-white px-4 border-t border-ink/5">
        <h2 className="text-4xl font-serif mb-8">Ready to receive your first letter?</h2>
        <a href="/stories" className="bg-ink text-white px-10 py-5 text-sm font-bold uppercase tracking-widest hover:bg-gold hover:text-ink transition-all inline-block shadow-xl">
          Browse the Archives
        </a>
      </section>
    </main>
  );
}
